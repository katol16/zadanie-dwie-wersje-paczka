var connect = require('connect');
var serveStatic = require('serve-static');
connect().use(serveStatic(__dirname)).listen(8080, function(){
    console.log('Server running on 8080...');
});

// https://stackoverflow.com/questions/6084360/using-node-js-as-a-simple-web-server
// HOW TO RUN SERVER
// 1) Install connect and serve-static with NPM

// $ npm install connect serve-static

// 2) Create server.js file with this content:

// var connect = require('connect');
// var serveStatic = require('serve-static');
// connect().use(serveStatic(__dirname)).listen(8080, function(){
//     console.log('Server running on 8080...');
// });

// 3) Run with Node.js

// $ node server.js