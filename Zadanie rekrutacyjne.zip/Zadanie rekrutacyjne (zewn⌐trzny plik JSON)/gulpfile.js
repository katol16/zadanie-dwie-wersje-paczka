var gulp = require('gulp');

// minifikacja CSS
// npm install --save-dev gulp-clean-css
var cleanCSS = require('gulp-clean-css');

gulp.task('css', function() {
	return gulp.src('assets/styles/**/*.css')
	.pipe(cleanCSS())
	.pipe(gulp.dest('distribution/assets/styles/'));
});

// minifikacja JavaScript
// npm install --save-dev gulp-uglify
var uglify = require('gulp-uglify');

gulp.task('js', function() {
	return gulp.src('assets/scripts/**/*.js')
	.pipe(uglify())
	.pipe(gulp.dest('distribution/assets/scripts/'));
});

// Optymalizacja i minifikacja plików HTML
// Instalujemy dwa pluginy
// npm install --save-dev gulp-html-replace gulp-htmlmin
// var htmlReplace = require('gulp-html-replace');
var htmlMin = require('gulp-htmlmin');

gulp.task('html', function() {
	return gulp.src('*.html')
	.pipe(htmlMin({
		sortAttributes: true,
		sortClassName: true,
		collapseWhitespace: true
	}))
	.pipe(gulp.dest('distribution/'));
});